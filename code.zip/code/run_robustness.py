"""Robustness analysis: Gaussian noise 5 % ... 25 % added to the input mammograms."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn.config import SETUPS
from acbn.experiments import run_analysis
from acbn.pipeline import PipelineConfig

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--noise-levels", nargs="+", type=int, default=SETUPS["noise_percentages"])
    a = finalize(p.parse_args())
    settings = [(f"{n}%", PipelineConfig(image_size=a.image_size, noise=n), "acbn") for n in a.noise_levels]
    run_analysis("robustness_analysis", settings, load_datasets(a), a.folds, a.epochs, a.seed, a.seg_epochs,
                 a.pseudo_masks, not a.no_pretrained, a.noise_levels, "Noise (%)", "lines", a.out)
