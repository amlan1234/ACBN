"""Analysis based on pre-processing (none / KWF / HE / KWF + HE)."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn.config import PREPROCESSING_VARIANTS
from acbn.experiments import run_analysis
from acbn.pipeline import PipelineConfig

if __name__ == "__main__":
    a = finalize(base_parser(__doc__).parse_args())
    settings = [(label, PipelineConfig(image_size=a.image_size, **kw), "acbn")
                for label, kw in PREPROCESSING_VARIANTS.items()]
    run_analysis("preprocessing_analysis", settings, load_datasets(a), a.folds, a.epochs, a.seed, a.seg_epochs,
                 a.pseudo_masks, not a.no_pretrained, kind="bars", out_root=a.out)
