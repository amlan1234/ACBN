"""Run every analysis with the paper settings: main, scalability, robustness, preprocessing, ablation, segmentation."""
import subprocess
import sys

SCRIPTS = ["main.py", "run_scalability.py", "run_robustness.py", "run_preprocessing_analysis.py",
           "run_ablation_study.py", "run_segmentation_analysis.py"]

if __name__ == "__main__":
    for s in SCRIPTS:
        print(f"\n################ {s} ################")
        subprocess.run([sys.executable, s] + sys.argv[1:], check=True)
