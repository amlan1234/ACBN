"""Scalability analysis: image size 32 ... 512 (K-fold, all six metrics, both datasets)."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn.config import SETUPS
from acbn.experiments import run_analysis
from acbn.pipeline import PipelineConfig

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--image-sizes", nargs="+", type=int, default=SETUPS["image_sizes"])
    a = finalize(p.parse_args())
    settings = [(f"{s}x{s}", PipelineConfig(image_size=s), "acbn") for s in a.image_sizes]
    run_analysis("scalability_analysis", settings, load_datasets(a), a.folds, a.epochs, a.seed, a.seg_epochs,
                 a.pseudo_masks, not a.no_pretrained, a.image_sizes, "Image size", "lines", a.out)
