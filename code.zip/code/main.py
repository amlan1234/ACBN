"""Run the proposed ACBN once (K-fold) on every dataset and print the six metrics of ``YL``."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn.config import YL
from acbn.experiments import run_analysis
from acbn.pipeline import PipelineConfig

if __name__ == "__main__":
    a = finalize(base_parser(__doc__).parse_args())
    run_analysis("main_results", [("Proposed ACBN", PipelineConfig(image_size=a.image_size), "acbn")],
                 load_datasets(a), a.folds, a.epochs, a.seed, a.seg_epochs, a.pseudo_masks,
                 not a.no_pretrained, kind="bars", out_root=a.out)
    import pandas as pd, glob, os
    from acbn.config import ROOT
    for f in sorted(glob.glob(os.path.join(a.out or os.path.join(ROOT, "results", "main_results"), "*", "*_summary.csv"))):
        print("\n" + f); print(pd.read_csv(f).T.to_string(header=False))
