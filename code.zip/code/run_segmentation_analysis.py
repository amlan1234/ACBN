"""Segmentation analysis: UF-EANet vs EANet(BCE) for 50-90 % training data (IoU, Dice)."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn import seg_analysis

if __name__ == "__main__":
    a = finalize(base_parser(__doc__).parse_args())
    seg_analysis.run(load_datasets(a), a.seg_epochs, a.seed, a.pseudo_masks, not a.no_pretrained, a.out)
