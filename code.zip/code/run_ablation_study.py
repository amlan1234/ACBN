"""Ablation study (w/o KWF, HE, EANet, Cutout, CSC-LBP; ADBNet only; DBN only; proposed ACBN)."""
from acbn.cli import base_parser, finalize, load_datasets
from acbn.config import ABLATION_VARIANTS
from acbn.experiments import run_analysis
from acbn.pipeline import PipelineConfig

if __name__ == "__main__":
    a = finalize(base_parser(__doc__).parse_args())
    settings = []
    for label, kw in ABLATION_VARIANTS.items():
        kw = dict(kw)
        variant = kw.pop("model", "acbn")
        settings.append((label, PipelineConfig(image_size=a.image_size, **kw), variant))
    run_analysis("ablation_study", settings, load_datasets(a), a.folds, a.epochs, a.seed, a.seg_epochs,
                 a.pseudo_masks, not a.no_pretrained, kind="bars", out_root=a.out)
