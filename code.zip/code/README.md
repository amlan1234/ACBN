# ACBN: Attention-guided Convolutional Belief Network for Breast Cancer Classification



---

# Minimum Hardware Requirements

| Component | Minimum Specification                                          |
|-----------|----------------------------------------------------------------|
| Operating System | Windows 10 (64-bit)                                            |
| Processor | Intel Core i3  or equivalent                                   |
| RAM | 8 GB Recommended                                               |
| GPU | Optional (CUDA-compatible GPU recommended for faster training) |
| Storage | 100 GB Free Disk Space                                         |
| Programming Language | Python 3.9.11                                                  |


---

## 1. Pipeline (block diagram of the paper, Figure 1)

```
Input mammogram
   -> Image denoising            Kernel Wiener Filtering (KWF)           Eqs. 2-6   acbn/preprocessing.py
   -> Enhancing separation       Histogram Equalization (HE)             Eq. 7      acbn/preprocessing.py
   -> Cancer region segmentation Unified-Focal-loss aware EANet          Eqs. 8-18  acbn/segmentation.py
   -> Image augmentation         Cutout                                  Eq. 19     acbn/augmentation.py
   -> Descriptor computation     CSC-LBP                                 Sec. 3.5   acbn/csc_lbp.py
   -> Classification             ACBN = ADBNet + DBN + Taylor fusion     Eqs. 37-45 acbn/acbn.py
        |- DBN    (RBM-pretrained, 512-256-128)                          Fig. 3     acbn/dbn.py, acbn/acbn.py
        |- ADBNet (Conv, Residual, SepConv, Deep Broad, CBAM)            Fig. 4     acbn/adbnet.py
   -> Normal | Benign | Malignant
```



---

## 2. Project structure

```
ACBN/
|-- README.md
|-- requirements.txt
|-- main.py                          run the proposed ACBN (K-fold) on every dataset
|-- run_scalability.py               Analysis 1 - image size 32 ... 512
|-- run_robustness.py                Analysis 2 - Gaussian noise 5 ... 25 %
|-- run_preprocessing_analysis.py    Analysis 3 - based on pre-processing
|-- run_ablation_study.py            Analysis 4 - ablation study
|-- run_segmentation_analysis.py     Segmentation analysis (IoU / Dice vs training data 50 ... 90 %)
|-- run_all.py                       runs everything above
|-- acbn/
|   |-- config.py                    Table 1 parameters, YL metric labels, all setups
|   |-- data.py                      dataset discovery / loading
|   |-- preprocessing.py             KWF, HE, noise injection
|   |-- segmentation.py              UF-EANet + unified focal loss
|   |-- augmentation.py              Cutout
|   |-- csc_lbp.py                   CSC-LBP map + descriptor
|   |-- dbn.py                       RBM / DBN layer-wise pre-training
|   |-- adbnet.py                    ADBNet
|   |-- acbn.py                      ACBN (Taylor fusion), training and prediction
|   |-- metrics.py                   acc, tpr, mcc, pre, f1s, spe
|   |-- pipeline.py                  feature pipeline with on/off switches + caching
|   |-- experiments.py               stratified K-fold driver, CSV tables, plots
|   |-- seg_analysis.py              segmentation analysis
|   |-- plotting.py                  figures (png + svg)
|   `-- cli.py                       shared command-line options
```

---

## 3. Installation

```bash
python -m venv venv
venv\Scripts\activate            # Windows   (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
```



## 4. Dataset layout

Put the datasets next to the code (or pass `--data-root`). The **class is the first sub-folder** of each dataset:

```
Dataset/
|-- MIAS/
|   |-- Normal/      *.png | *.jpg | *.pgm ...
|   `-- Malignant/   image.png  +  image_GT.png   (ground-truth mask)
`-- DDSM_DB2/
    |-- Normal/
    `-- Benign/      image.png  +  image_GT.png
```
* Any file whose name contains `GT` / `mask` (or that sits in a `gt`/`mask` folder) is a ground-truth mask and is
  matched to its image by file name. Images without a mask are treated as lesion-free.
* The UF-EANet needs ground-truth masks for training. If a dataset has none, run with `--pseudo-masks`
  (Otsu pseudo labels - weak supervision, use only for experimentation).
* Dataset folder names are set in `acbn/config.py -> DATASETS`.

---

## 5. Running

```bash
python main.py                          # proposed ACBN, both datasets, all six metrics
python run_scalability.py               # Analysis 1
python run_robustness.py                # Analysis 2
python run_preprocessing_analysis.py    # Analysis 3
python run_ablation_study.py            # Analysis 4
python run_segmentation_analysis.py     # segmentation analysis
python run_all.py                       # everything
```

Common options (all scripts):

| Option | Default | Meaning |
|---|---|---|
| `--data-root` | `./Dataset` | folder containing `MIAS` and `DDSM_DB2` |
| `--datasets` | `MIAS DDSM` | datasets to run |
| `--epochs` | 100 | ACBN training epochs (Table 1) |
| `--folds` | 10 | stratified K-fold |
| `--seg-epochs` | 50 | UF-EANet training epochs |
| `--image-size` | 128 | operating image size of the robustness / preprocessing / ablation / main runs |
| `--image-sizes` | 32 64 128 256 512 | (scalability only) |
| `--noise-levels` | 5 10 15 20 25 | (robustness only) |
| `--pseudo-masks` | off | Otsu pseudo masks when no GT masks exist |
| `--quick` | off | smoke test: 3 epochs, 3 folds, 2 segmentation epochs |
| `--out` | `./results/<analysis>` | output folder |

Every model training (each fold, each segmentation network) runs in its own short-lived worker process
(`acbn/isolate.py`). TensorFlow otherwise keeps graph memory alive across many model builds, which exhausts an 8 GB
machine during multi-setup runs. Set the environment variable `ACBN_NO_ISOLATE=1` to run in-process for debugging.
On Windows the scripts must be started as files (`python run_*.py`), which is the normal way.

Intermediate results are cached (`cache/` = features, `models/` = segmentation weights,
`results/_cache/` = finished settings, `results/segmentation_analysis/_cache/` = finished segmentation trainings), so an interrupted run resumes where it stopped.
Delete these folders to recompute from scratch.

### The analyses

| # | Script | Settings evaluated (per dataset) |
|---|---|---|
| - | `main.py` | Proposed ACBN |
| 1 | `run_scalability.py` | image size 32, 64, 128, 256, 512 |
| 2 | `run_robustness.py` | Gaussian noise 5, 10, 15, 20, 25 % |
| 3 | `run_preprocessing_analysis.py` | ACBN without preprocessing / with KWF / with HE / with KWF + HE |
| 4 | `run_ablation_study.py` | ACBN without KWF / without HE / without EANet / without Cutout / without CSC-LBP / ADBNet / DBN / Proposed ACBN |
| - | `run_segmentation_analysis.py` | Unified Focal EANet vs EANet (BCE loss), training data 50-90 % |

Every setting is evaluated with **stratified K-fold cross-validation** and reports the six metrics of
`YL = {"acc": "Accuracy(%)", "tpr": "TPR(%)", "mcc": "MCC", "pre": "Precision(%)", "f1s": "F1-score(%)", "spe": "Specificity(%)"}`.

Outputs, e.g. `results/ablation_study/MIAS/`:

| File | Content |
|---|---|
| `MIAS_<metric>_val.csv` | value of every fold for every setting |
| `MIAS_<metric>_stat.csv` | mean, variance and standard deviation over the folds |
| `MIAS_summary.csv` | one row per setting: mean and std of all six metrics |
| `MIAS_<metric>.png/.svg` | figure (bars with std for the variant analyses, line for scalability / robustness) |

`<metric>` is one of `acc, tpr, mcc, pre, f1s, spe`.

---

## 6. Parameters (Table 1) and where they are used

| Parameter | Value | Used in |
|---|---|---|
| Batch size | 32 | `acbn.train_and_predict` |
| Epochs | 100 | `acbn.train_and_predict` |
| Optimizer / learning rate | Adam, 0.001 (beta1 0.9, beta2 0.999) | `acbn.train_and_predict` |
| LR scheduler | ReduceLROnPlateau | `acbn.train_and_predict` |
| Weight decay (L2) | 1e-4 | L2 regulariser on every conv / dense kernel (`adbnet.py`, `acbn.py`) |
| Dropout | 0.5 | `adbnet.adbnet_graph` |
| Activation | ReLU (GELU in residual / Deep Broad blocks as in Eqs. 27-35) | `adbnet.py` |
| Output activation | Softmax | ADBNet, DBN and ACBN output |
| Loss | Categorical cross-entropy | `acbn.train_and_predict` |
| Attention reduction ratio | 16 | `adbnet.cbam` |
| Kernel size / pooling | 3 x 3 / 2 x 2 max | `adbnet.py` |
| Broad feature maps | 64 | `adbnet.deep_broad_block` |
| DBN hidden layers / neurons | 3 / 512-256-128 | `acbn._dbn_graph`, `dbn.pretrain_dbn` |
| RBM learning rate / batch | 0.01 / 64 | `dbn.pretrain_dbn` |

