"""Cancer region segmentation: Unified-Focal-loss aware iterative Edge Attention Network.

Components follow Section 3.3 of the paper
  * VGG-19 encoder
  * DSC  : three parallel dilated convs, adjacent-scale fusion, residual aggregation (Eq. 8)
  * EAP  : gated convolution blocks + edge supervision (Eqs. 9-10)
  * Decoder : reverse attention (Eq. 11), Hybrid Feature Fusion (4 parallel dilated convs),
              Multi-level Pairwise Regression = deep supervision on every decoder level
  * Loss : asymmetric Unified Focal loss (Eqs. 12-18)
"""
import os
import numpy as np
import cv2
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from .config import IMPL


# ----------------------------------------------------------------------------
# Unified focal loss (single foreground channel p, background channel 1-p)
# ----------------------------------------------------------------------------
def _tversky(y, p, eta, eps=1e-6):
    """mTI of Eq. 14 - FN weighted by eta, FP by (1-eta)  (class = foreground)."""
    tp = tf.reduce_sum(y * p, axis=[1, 2, 3])
    fn = tf.reduce_sum(y * (1 - p), axis=[1, 2, 3])
    fp = tf.reduce_sum((1 - y) * p, axis=[1, 2, 3])
    return (tp + eps) / (tp + eta * fn + (1 - eta) * fp + eps)


def unified_focal_loss(eta=None, chi=None, psi=None):
    """Q_aUF = psi * Q_MAFL + (1-psi) * Q_MAFTL   (Eq. 18); rare class n = lesion."""
    eta = IMPL["uf_eta"] if eta is None else eta
    chi = IMPL["uf_chi"] if chi is None else chi
    psi = IMPL["uf_psi"] if psi is None else psi

    def loss(y_true, y_pred):
        y = tf.cast(y_true, tf.float32)
        p = tf.clip_by_value(tf.cast(y_pred, tf.float32), 1e-7, 1 - 1e-7)
        # Eq. 16  - rare class keeps full weight, background is focally suppressed
        mafl = -(eta * y * tf.math.log(p)
                 + (1 - eta) * (1 - y) * tf.pow(p, chi) * tf.math.log(1 - p))
        mafl = tf.reduce_mean(mafl, axis=[1, 2, 3])
        # Eq. 17  - background term (1-mTI) + rare-class term (1-mTI)^(1-chi)
        ti_fg = _tversky(y, p, eta)
        ti_bg = _tversky(1 - y, 1 - p, eta)
        maftl = (1 - ti_bg) + tf.pow(1 - ti_fg, 1 - chi)
        return tf.reduce_mean(psi * mafl + (1 - psi) * maftl)
    return loss


def bce_loss(y_true, y_pred):
    return tf.reduce_mean(keras.losses.binary_crossentropy(y_true, y_pred))


# ----------------------------------------------------------------------------
# Network
# ----------------------------------------------------------------------------
def _cbr(x, f, k=3, d=1):
    x = layers.Conv2D(f, k, padding="same", dilation_rate=d, use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    return layers.ReLU()(x)


def _resize_like(x, ref):
    return layers.Lambda(lambda t: tf.image.resize(t[0], tf.shape(t[1])[1:3], method="bilinear"))([x, ref])


def _pair_fuse(a, b, ch):
    """Adjacent-scale fusion: sigmoid-gate branch x softmax-weight branch."""
    cat = layers.Concatenate()([a, b])
    gate = layers.Conv2D(ch, 1, activation="sigmoid")(cat)
    w = layers.Conv2D(ch, 1)(cat)
    w = _cbr(_cbr(w, ch), ch)
    w = layers.Conv2D(2, 1)(w)
    w = layers.Softmax(axis=-1)(w)
    fused = layers.Lambda(lambda t: t[0] * t[2][..., 0:1] + t[1] * t[2][..., 1:2])([a, b, w])
    return layers.Multiply()([gate, fused])


def _dsc(x, ch):
    f = [_cbr(x, ch, 3, d) for d in IMPL["seg_dsc_dilations"]]          # three dilated branches
    p12, p23 = _pair_fuse(f[0], f[1], ch), _pair_fuse(f[1], f[2], ch)
    pin = layers.Conv2D(ch, 1)(x)
    s = layers.Add()([p12, p23, pin])
    return layers.BatchNormalization()(layers.ReLU()(s))                # Eq. 8: W(delta(P12+P23+Pin))


def _gcb(stream, enc):
    """Gated convolution block (Eq. 9)."""
    ch = stream.shape[-1]
    e = layers.Conv2D(ch, 1)(enc)
    e = _resize_like(e, stream)
    att = layers.Concatenate()([stream, e])
    att = layers.Conv2D(ch, 1)(att)
    att = layers.BatchNormalization()(att)
    att = layers.ReLU()(att)
    att = layers.Conv2D(1, 1, activation="sigmoid")(att)                # attention map lambda
    gated = layers.Lambda(lambda t: t[0] * t[1] + t[0])([stream, att])      # (s * lambda) + s
    return _cbr(gated, ch)


def _hff(x, ch):
    """Hybrid Feature Fusion: four parallel multi-scale branches."""
    br = [_cbr(x, ch // 2, 3, d) for d in (1, 2, 3, 4)]
    return _cbr(layers.Concatenate()(br), ch, 1)


def _decoder_stage(prev_feat, prev_logit, skip, edge, ch):
    up = _resize_like(prev_feat, skip)
    prev_up = _resize_like(prev_logit, skip)
    rev = layers.Lambda(lambda t: 1.0 - tf.sigmoid(t))(prev_up)         # reverse attention (Eq. 11)
    edge_r = _resize_like(edge, skip)
    guided = layers.Lambda(lambda t: t[0] * (1.0 + t[1]) * (1.0 + t[2]))([skip, rev, edge_r])
    x = layers.Concatenate()([up, _hff(guided, ch)])
    x = _cbr(x, ch)
    logit = layers.Conv2D(1, 1)(x)
    return x, logit


def build_eanet(size=None, pretrained=True):
    size = size or IMPL["seg_size"]
    ch = IMPL["seg_channels"]
    weights = None
    if pretrained:
        try:
            keras.applications.VGG19(include_top=False, weights="imagenet", input_shape=(size, size, 3))
            weights = "imagenet"
        except Exception as ex:                                          # offline machines
            print(f"[segmentation] ImageNet weights unavailable ({type(ex).__name__}); "
                  f"VGG-19 encoder is randomly initialised.")
    vgg = keras.applications.VGG19(include_top=False, weights=weights, input_shape=(size, size, 3))
    names = ["block1_conv2", "block2_conv2", "block3_conv4", "block4_conv4", "block5_conv4"]
    enc = keras.Model(vgg.input, [vgg.get_layer(n).output for n in names])

    inp = keras.Input((size, size, 1))
    x3 = layers.Concatenate()([inp, inp, inp])
    x3 = layers.Lambda(lambda t: t * 255.0 - tf.constant([103.939, 116.779, 123.68]))(x3)
    e1, e2, e3, e4, e5 = enc(x3)

    # DSC on the deepest features
    d5 = _dsc(e5, ch)
    # EAP : edge stream from the lowest level refined by gated conv blocks
    stream = _cbr(e1, 32, 1)
    for e in (e2, e3, e4):
        stream = _gcb(stream, e)
    edge = layers.Conv2D(1, 1, activation="sigmoid", name="edge")(stream)

    logit5 = layers.Conv2D(1, 1)(d5)
    f4, l4 = _decoder_stage(d5, logit5, e4, edge, ch)
    f3, l3 = _decoder_stage(f4, l4, e3, edge, ch // 2)
    f2, l2 = _decoder_stage(f3, l3, e2, edge, ch // 4)
    f1, l1 = _decoder_stage(f2, l2, e1, edge, ch // 4)

    # Multi-level Pairwise Regression: every level supervised, fused prediction on top
    ups = [layers.Lambda(lambda t: tf.image.resize(t[0], tf.shape(t[1])[1:3]))([l, inp]) for l in (l1, l2, l3, l4)]
    fused = layers.Conv2D(1, 1)(layers.Concatenate()(ups))
    out = layers.Activation("sigmoid", name="seg")(fused)
    sides = [layers.Activation("sigmoid", name=f"side{i + 1}")(u) for i, u in enumerate(ups)]
    edge_full = layers.Lambda(lambda t: tf.image.resize(t[0], tf.shape(t[1])[1:3]), name="edge_up")([edge, inp])
    return keras.Model(inp, [out] + sides + [edge_full])


def _edge_gt(masks):
    k = np.ones((3, 3), np.uint8)
    return np.stack([cv2.morphologyEx(m, cv2.MORPH_GRADIENT, k) for m in masks.astype(np.uint8)])


def compile_eanet(model, loss="unified"):
    seg_loss = unified_focal_loss() if loss == "unified" else bce_loss
    losses = [seg_loss] * 5 + [bce_loss]                                  # seg, 4 side outputs, edge
    weights = [1.0, 0.25, 0.25, 0.25, 0.25, 0.5]
    model.compile(optimizer=keras.optimizers.Adam(IMPL["seg_lr"]), loss=losses, loss_weights=weights)


def train_eanet(images, masks, size=None, epochs=None, loss="unified", pretrained=True, verbose=0, seed=0):
    """images / masks : uint8 arrays (N,H,W) already at ``size`` (masks in {0,1})."""
    keras.utils.set_random_seed(seed)
    size = size or IMPL["seg_size"]
    model = build_eanet(size, pretrained)
    compile_eanet(model, loss)
    x = (images.astype(np.float32) / 255.0)[..., None]
    m = masks.astype(np.float32)[..., None]
    e = _edge_gt(masks).astype(np.float32)[..., None]
    model.fit(x, [m, m, m, m, m, e], batch_size=IMPL["seg_batch"],
              epochs=epochs or IMPL["seg_epochs"], verbose=verbose, shuffle=True)
    return model


def predict_prob(model, images, size=None):
    """images: uint8 (N,H,W) at any resolution -> probability maps (N,H,W) at the same resolution."""
    size = size or IMPL["seg_size"]
    n, h, w = images.shape
    small = np.stack([cv2.resize(i, (size, size), interpolation=cv2.INTER_AREA) for i in images])
    x = (small.astype(np.float32) / 255.0)[..., None]
    out = model.predict(x, batch_size=IMPL["seg_batch"], verbose=0)[0][..., 0]
    if (h, w) != (size, size):
        out = np.stack([cv2.resize(o, (w, h), interpolation=cv2.INTER_LINEAR) for o in out])
    return out


def segment(model, images, size=None):
    """E_g = enhanced image restricted to the predicted cancer region.

    Returns (segmented uint8 images, number of images that fell back to the full image)."""
    prob = predict_prob(model, images, size)
    seg = np.zeros_like(images)
    fallback = 0
    for i, (im, pr) in enumerate(zip(images, prob)):
        mask = pr > IMPL["seg_threshold"]
        if mask.sum() == 0 and IMPL["seg_empty_fallback"]:
            seg[i] = im
            fallback += 1
        else:
            seg[i] = im * mask
    return seg, fallback


def iou_dice(pred_prob, gt, thr=None):
    thr = IMPL["seg_threshold"] if thr is None else thr
    p = pred_prob > thr
    g = gt.astype(bool)
    inter = np.logical_and(p, g).sum(axis=(1, 2)).astype(np.float64)
    union = np.logical_or(p, g).sum(axis=(1, 2)).astype(np.float64)
    ps, gs = p.sum(axis=(1, 2)), g.sum(axis=(1, 2))
    iou = np.where(union > 0, inter / np.maximum(union, 1), 1.0)
    dice = np.where(ps + gs > 0, 2 * inter / np.maximum(ps + gs, 1), 1.0)
    return float(iou.mean()), float(dice.mean())
