"""Stratified K-fold evaluation of one experimental setting + generic analysis driver."""
import json
import os
import time

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

from . import data as D
from .acbn import train_and_predict
from .isolate import run_isolated
from .config import METRIC_KEYS, PARAMS, ROOT, YL, IMPL
from .metrics import compute_metrics
from .pipeline import PipelineConfig, build_features, _hash
from .plotting import plot_bars, plot_lines
from dataclasses import asdict

RESULTS = os.path.join(ROOT, "results")


def evaluate(dataset, records, classes, cfg, model_variant="acbn", folds=10, epochs=None, seed=0,
             seg_epochs=None, allow_pseudo=False, pretrained=True, use_cache=True):
    """Returns {metric: [value per fold]} for one setting (cached on disk)."""
    epochs = epochs or PARAMS["epochs"]
    key = _hash({"d": dataset, "cfg": asdict(cfg), "m": model_variant, "k": folds, "e": epochs, "s": seed,
                 "se": seg_epochs or IMPL["seg_epochs"], "n": len(records), "pm": {k: str(v) for k, v in PARAMS.items()}})
    cpath = os.path.join(RESULTS, "_cache", f"{dataset}_{key}.json")
    if use_cache and os.path.exists(cpath):
        with open(cpath) as f:
            return json.load(f)
    feats = build_features(dataset, records, cfg, seed, seg_epochs, allow_pseudo, pretrained, use_cache)
    y = feats["labels"]
    n_classes = len(classes)
    k = min(folds, int(np.bincount(y).min()))
    if k < folds:
        print(f"[evaluate] {dataset}: smallest class has {int(np.bincount(y).min())} images -> using {k} folds")
    if k < 2:
        raise RuntimeError("Each class needs at least 2 images for cross validation.")
    res = {m: [] for m in METRIC_KEYS}
    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    for f, (tr, te) in enumerate(skf.split(feats["maps"], y)):
        t0 = time.time()
        # training set = originals + Cutout copies of the *training* images only (no leakage)
        tm = [feats["maps"][tr]]; th = [feats["hists"][tr]]; ty = [y[tr]]
        if feats["aug_maps"].shape[1]:
            c = feats["aug_maps"].shape[1]
            tm.append(feats["aug_maps"][tr].reshape(-1, *feats["maps"].shape[1:]))
            th.append(feats["aug_hists"][tr].reshape(-1, feats["hists"].shape[1]))
            ty.append(np.repeat(y[tr], c))
        pred = run_isolated(train_and_predict, (np.concatenate(tm), np.concatenate(th), np.concatenate(ty)),
                            (feats["maps"][te], feats["hists"][te], y[te]),
                            n_classes, model_variant, epochs, seed + f)
        m = compute_metrics(y[te], pred, n_classes)
        for kk in METRIC_KEYS:
            res[kk].append(float(m[kk]))
        print(f"  fold {f + 1}/{k}  acc={m['acc']:.2f}  mcc={m['mcc']:.3f}  ({time.time() - t0:.0f}s)")
    if use_cache:
        os.makedirs(os.path.dirname(cpath), exist_ok=True)
        with open(cpath, "w") as fh:
            json.dump(res, fh)
    return res


def save_tables(out_dir, dataset, labels, results):
    """results[label] = {metric: [per fold]}.  Writes *_val.csv, *_stat.csv, summary.csv"""
    os.makedirs(out_dir, exist_ok=True)
    summary = []
    for mk in METRIC_KEYS:
        n = max(len(results[l][mk]) for l in labels)
        val = pd.DataFrame({l: pd.Series(results[l][mk]) for l in labels})
        val.index = [f"fold{i + 1}" for i in range(n)]
        val.to_csv(os.path.join(out_dir, f"{dataset}_{mk}_val.csv"))
        stat = pd.DataFrame({"mean": val.mean(), "variance": val.var(ddof=0), "std": val.std(ddof=0)}).T
        stat.to_csv(os.path.join(out_dir, f"{dataset}_{mk}_stat.csv"))
    for l in labels:
        row = {"setting": l}
        for mk in METRIC_KEYS:
            row[YL[mk]] = float(np.mean(results[l][mk]))
            row[YL[mk] + " std"] = float(np.std(results[l][mk]))
        summary.append(row)
    pd.DataFrame(summary).to_csv(os.path.join(out_dir, f"{dataset}_summary.csv"), index=False)


def run_analysis(name, settings, datasets_info, folds, epochs, seed, seg_epochs, allow_pseudo,
                 pretrained=True, x_values=None, x_label=None, kind="bars", out_root=None):
    """settings = [(label, PipelineConfig, model_variant)].  datasets_info = {name: (records, classes)}."""
    out_root = out_root or os.path.join(RESULTS, name)
    for ds, (records, classes) in datasets_info.items():
        print(f"\n===== {name} | {ds} ({len(records)} images, classes={classes}) =====")
        results, labels = {}, []
        for label, cfg, variant in settings:
            print(f"-- {label}")
            results[label] = evaluate(ds, records, classes, cfg, variant, folds, epochs, seed, seg_epochs,
                                      allow_pseudo, pretrained)
            labels.append(label)
        d = os.path.join(out_root, ds)
        save_tables(d, ds, labels, results)
        for mk in METRIC_KEYS:
            vals = [np.array(results[l][mk]) for l in labels]
            if kind == "lines":
                plot_lines(os.path.join(d, f"{ds}_{mk}"), x_values, vals, YL[mk], x_label, ds)
            else:
                plot_bars(os.path.join(d, f"{ds}_{mk}"), labels, vals, YL[mk], ds)
        print(f"[saved] {d}")
