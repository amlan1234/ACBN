"""End-to-end feature pipeline (Fig. 1):

 input image -> [noise] -> KWF -> HE -> UF-EANet segmentation -> Cutout (training copies) -> CSC-LBP

Every switch can be turned off, which is how the preprocessing and ablation analyses are produced.
"""
import hashlib
import json
import os
from dataclasses import dataclass, asdict

import cv2
import numpy as np

from . import data as D
from .augmentation import cutout
from .config import IMPL, ROOT
from .isolate import run_isolated
from .csc_lbp import csc_lbp_map, code_histogram, intensity_histogram, descriptor_dim
from .preprocessing import prepare_batch, add_noise, histogram_equalization

CACHE = os.path.join(ROOT, "cache")
MODELS = os.path.join(ROOT, "models")


@dataclass(frozen=True)
class PipelineConfig:
    image_size: int = 128
    kwf: bool = True
    he: bool = True
    seg: bool = True
    cutout: bool = True
    csc: bool = True
    noise: int = 0          # percent


def _hash(obj):
    return hashlib.md5(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]


# --------------------------------------------------------------------------- segmentation model
def pseudo_masks(prepared):
    """Weak labels (Otsu on the enhanced image) - only when no ground-truth masks exist."""
    out = []
    for im in prepared:
        _, m = cv2.threshold(im, 0, 1, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        out.append(m.astype(np.uint8))
    return np.stack(out)


def seg_training_data(records, kwf, he, allow_pseudo=False):
    size = IMPL["seg_size"]
    imgs = prepare_batch(D.load_images(records, size), kwf, he)
    if D.has_masks(records):
        masks = D.load_masks(records, size)
    elif allow_pseudo:
        print("[segmentation] WARNING: no ground-truth masks found - training on Otsu pseudo-masks.")
        masks = pseudo_masks(imgs)
    else:
        raise RuntimeError("No ground-truth masks (files containing 'GT') were found for this dataset. "
                           "Provide masks or run with --pseudo-masks.")
    return imgs, masks


def get_segmenter(dataset, records, kwf=True, he=True, epochs=None, allow_pseudo=False, pretrained=True, verbose=0):
    """Train the UF-EANet once per (dataset, preprocessing) and cache the weights on disk."""
    from . import segmentation as S
    epochs = epochs or IMPL["seg_epochs"]
    tag = f"{dataset}_k{int(kwf)}h{int(he)}_s{IMPL['seg_size']}_e{epochs}"
    os.makedirs(MODELS, exist_ok=True)
    path = os.path.join(MODELS, f"seg_{tag}.weights.h5")
    if os.path.exists(path):
        model = S.build_eanet(IMPL["seg_size"], pretrained=False)
        model.load_weights(path)
    else:
        imgs, masks = seg_training_data(records, kwf, he, allow_pseudo)
        print(f"[segmentation] training UF-EANet for {tag} ({len(imgs)} images, {epochs} epochs)")
        model = S.train_eanet(imgs, masks, IMPL["seg_size"], epochs, "unified", pretrained, verbose)
        model.save_weights(path)
    return model


def _segment_worker(dataset, records, kwf, he, seg_epochs, allow_pseudo, pretrained, prep):
    """Runs in a worker process: (train or load) the UF-EANet and segment ``prep``."""
    from . import segmentation as SG
    model = get_segmenter(dataset, records, kwf, he, seg_epochs, allow_pseudo, pretrained)
    return SG.segment(model, prep)


# --------------------------------------------------------------------------- features
def _describe(img, csc):
    if csc:
        m = csc_lbp_map(img)
        return m, code_histogram(m)
    return img, intensity_histogram(img, descriptor_dim())


def build_features(dataset, records, cfg, seed=0, seg_epochs=None, allow_pseudo=False, pretrained=True, use_cache=True):
    """Returns dict(maps, hists, aug_maps, aug_hists, labels).  Maps are uint8 (N,S,S)."""
    key = _hash({"d": dataset, "cfg": asdict(cfg), "seed": seed, "n": len(records),
                 "se": seg_epochs or IMPL["seg_epochs"], "impl": {k: IMPL[k] for k in sorted(IMPL)}})
    path = os.path.join(CACHE, f"feat_{dataset}_{key}.npz")
    if use_cache and os.path.exists(path):
        z = np.load(path)
        return {k: z[k] for k in z.files}
    S = cfg.image_size
    rng = np.random.default_rng(seed)
    raw = D.load_images(records, S)
    if cfg.noise:
        raw = add_noise(raw, cfg.noise, np.random.default_rng(seed + 1000 + cfg.noise))
    prep = prepare_batch(raw, cfg.kwf, cfg.he)
    fb = 0
    if cfg.seg:
        eg, fb = run_isolated(_segment_worker, dataset, records, cfg.kwf, cfg.he, seg_epochs,
                              allow_pseudo, pretrained, prep)
        print(f"[pipeline] {dataset} size={S}: {fb}/{len(eg)} images had an empty mask (full image used)")
    else:
        eg = prep
    maps, hists = zip(*[_describe(i, cfg.csc) for i in eg])
    out = {"maps": np.stack(maps).astype(np.uint8), "hists": np.stack(hists).astype(np.float32),
           "labels": D.labels_of(records)}
    copies = IMPL["cutout_copies"] if cfg.cutout else 0
    am, ah = [], []
    for c in range(copies):
        res = [_describe(cutout(i, rng), cfg.csc) for i in eg]
        am.append(np.stack([r[0] for r in res]).astype(np.uint8))
        ah.append(np.stack([r[1] for r in res]).astype(np.float32))
    out["aug_maps"] = np.stack(am, 1) if am else np.zeros((len(eg), 0, S, S), np.uint8)
    out["aug_hists"] = np.stack(ah, 1) if ah else np.zeros((len(eg), 0, descriptor_dim()), np.float32)
    if use_cache:
        os.makedirs(CACHE, exist_ok=True)
        np.savez_compressed(path, **out)
    return out
