"""ACBN: Attention-guided Convolutional Belief Network for Breast Cancer Classification."""
