"""Dataset discovery and image loading.

Expected layout (class = first sub-folder below the dataset folder)::

    Dataset/MIAS/Normal/xxx.png
    Dataset/MIAS/Malignant/yyy.png
    Dataset/MIAS/Malignant/yyy_GT.png      <- optional ground-truth mask
    Dataset/DDSM_DB2/Normal/...  Dataset/DDSM_DB2/Benign/...

A file is treated as a ground-truth mask when its name contains ``GT`` / ``mask``
(case-insensitive) or it lives in a folder called ``gt`` / ``mask(s)``.
A mask is matched to its image by the normalised file stem.
"""
import os
import re
import numpy as np
import cv2

IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".pgm")


def _is_mask(path):
    name = os.path.splitext(os.path.basename(path))[0].lower()
    parts = [p.lower() for p in os.path.normpath(path).split(os.sep)[:-1]]
    return ("gt" in re.split(r"[^a-z0-9]+", name) or "mask" in name
            or any(p in ("gt", "mask", "masks", "groundtruth") for p in parts))


def _key(path):
    stem = os.path.splitext(os.path.basename(path))[0].lower()
    stem = re.sub(r"(^|[^a-z0-9])(gt|mask)([^a-z0-9]|$)", " ", stem)
    return re.sub(r"[^a-z0-9]", "", stem)


def discover(root):
    """Return (records, classes).  records = [(image_path, class_idx, mask_path|None)]."""
    if not os.path.isdir(root):
        raise FileNotFoundError(f"Dataset folder not found: {root}")
    images, masks = [], {}
    for dirname, _, files in os.walk(root):
        for f in sorted(files):
            if not f.lower().endswith(IMG_EXT):
                continue
            p = os.path.join(dirname, f)
            if _is_mask(p):
                masks[(os.path.relpath(dirname, root).split(os.sep)[0], _key(p))] = p
            else:
                images.append(p)
    if not images:
        raise RuntimeError(f"No images found in {root}")
    cls_of = lambda p: os.path.relpath(p, root).split(os.sep)[0]
    for p in images:
        if os.sep not in os.path.relpath(p, root):
            raise RuntimeError(f"{p}: images must sit inside a class sub-folder of {root}")
    classes = sorted({cls_of(p) for p in images})
    records = []
    for p in sorted(images):
        records.append((p, classes.index(cls_of(p)), masks.get((cls_of(p), _key(p)))))
    return records, classes


def has_masks(records):
    return any(m is not None for _, _, m in records)


def load_gray(path, size):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise IOError(f"Cannot read image {path}")
    return cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)


def load_mask(path, size):
    if path is None:                       # no mask file -> lesion-free image
        return np.zeros((size, size), np.uint8)
    m = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if m is None:
        raise IOError(f"Cannot read mask {path}")
    m = cv2.resize(m, (size, size), interpolation=cv2.INTER_NEAREST)
    return (m > 127).astype(np.uint8)


def load_images(records, size):
    return np.stack([load_gray(p, size) for p, _, _ in records]).astype(np.uint8)


def load_masks(records, size):
    return np.stack([load_mask(m, size) for _, _, m in records]).astype(np.uint8)


def labels_of(records):
    return np.array([c for _, c, _ in records], dtype=np.int64)
