"""Run a heavy TensorFlow job in a fresh worker process.

TensorFlow/Keras keeps graph memory alive when many models are built in one process.
Running every training job in a short-lived 'spawn' worker returns all of it to the OS,
which keeps long K-fold / multi-setup runs inside an 8 GB machine.  Set ACBN_NO_ISOLATE=1
to run in-process (useful for debugging).
"""
import multiprocessing as mp
import os


def run_isolated(fn, *args):
    if os.environ.get("ACBN_NO_ISOLATE") == "1":
        return fn(*args)
    ctx = mp.get_context("spawn")
    with ctx.Pool(1, maxtasksperchild=1) as pool:
        return pool.apply(fn, args)
