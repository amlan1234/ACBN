"""Circular Shift Combination LBP (CSC-LBP, Section 3.5), vectorised.

Every pixel gets a P-bit LBP pattern (neighbour >= centre).  All P circular
shifts of the pattern are combined and the minimum is kept, which makes the code
rotation invariant.  The result is the feature map ``L_g``; its normalised
histogram over the distinct codes is the compact descriptor used by the DBN.
"""
import numpy as np
from .config import IMPL


def _canonical_lut(P):
    lut = np.zeros(1 << P, dtype=np.uint16)
    mask = (1 << P) - 1
    for code in range(1 << P):
        lut[code] = min(((code >> s) | (code << (P - s))) & mask for s in range(P))
    return lut


_LUTS = {}


def lut_and_bins(P):
    if P not in _LUTS:
        lut = _canonical_lut(P)
        bins = np.unique(lut)
        index = np.zeros(1 << P, dtype=np.int32)
        index[bins] = np.arange(len(bins))
        _LUTS[P] = (lut, bins, index)
    return _LUTS[P]


def descriptor_dim(P=None):
    return len(lut_and_bins(P or IMPL["lbp_points"])[1])


def csc_lbp_map(img, P=None, R=None):
    """img: 2-D uint8.  Returns uint8 map of canonical codes (value range 0..2^P-1)."""
    P = P or IMPL["lbp_points"]
    R = R or IMPL["lbp_radius"]
    lut, _, _ = lut_and_bins(P)
    h, w = img.shape
    im = img.astype(np.int16)
    pad = np.pad(im, R, mode="reflect")
    code = np.zeros((h, w), dtype=np.int32)
    for p in range(P):
        th = 2 * np.pi * p / P
        dr = int(round(R * np.cos(th)))
        dc = int(round(-R * np.sin(th)))
        nb = pad[R + dr:R + dr + h, R + dc:R + dc + w]
        code |= (nb >= im).astype(np.int32) << p
    return lut[code].astype(np.uint8)


def code_histogram(code_map, P=None):
    """Descriptor in [0, 1]: histogram over the distinct canonical codes (max-scaled)."""
    P = P or IMPL["lbp_points"]
    _, bins, index = lut_and_bins(P)
    h = np.bincount(index[code_map.ravel()], minlength=len(bins)).astype(np.float32)
    return h / max(h.max(), 1.0)


def intensity_histogram(img, nbins):
    """Used only by the 'ACBN without CSC-LBP' ablation (same descriptor length)."""
    h, _ = np.histogram(img.ravel(), bins=nbins, range=(0, 256))
    h = h.astype(np.float32)
    return h / max(h.max(), 1.0)
