"""Classification metrics returned by every run: acc, tpr, mcc, pre, f1s, spe."""
import numpy as np
from sklearn.metrics import confusion_matrix, matthews_corrcoef
from .config import METRIC_KEYS, IMPL


def _div(a, b):
    return np.where(b > 0, a / np.maximum(b, 1e-12), 0.0)


def compute_metrics(y_true, y_pred, n_classes, average=None):
    """Returns dict with keys of ``config.YL``.  All but MCC are in percent.

    Per-class one-vs-rest TP/FP/FN/TN are averaged (macro by default).  Accuracy is
    the overall fraction of correct predictions.  MCC is the multi-class MCC.
    """
    average = average or IMPL["metric_average"]
    cm = confusion_matrix(y_true, y_pred, labels=list(range(n_classes))).astype(np.float64)
    tp = np.diag(cm); fp = cm.sum(0) - tp; fn = cm.sum(1) - tp; tn = cm.sum() - tp - fp - fn
    tpr, pre, spe = _div(tp, tp + fn), _div(tp, tp + fp), _div(tn, tn + fp)
    f1 = _div(2 * tp, 2 * tp + fp + fn)
    if average == "micro":
        TP, FP, FN, TN = tp.sum(), fp.sum(), fn.sum(), tn.sum()
        agg = [float(_div(TP, TP + FN)), float(_div(TP, TP + FP)),
               float(_div(TN, TN + FP)), float(_div(2 * TP, 2 * TP + FP + FN))]
    else:
        w = (cm.sum(1) / cm.sum()) if average == "weighted" else np.ones(n_classes) / n_classes
        agg = [float(np.sum(w * v)) for v in (tpr, pre, spe, f1)]
    out = {"acc": 100.0 * tp.sum() / cm.sum(), "tpr": 100.0 * agg[0], "pre": 100.0 * agg[1],
           "spe": 100.0 * agg[2], "f1s": 100.0 * agg[3],
           "mcc": float(matthews_corrcoef(y_true, y_pred))}
    return {k: out[k] for k in METRIC_KEYS}
