"""Shared command line handling for all run_*.py scripts."""
import argparse
import os

from . import data as D
from .config import DATASETS, IMPL, PARAMS, SETUPS, ROOT


def base_parser(desc):
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--data-root", default=os.path.join(ROOT, "Dataset"), help="folder that contains the dataset folders")
    p.add_argument("--datasets", nargs="+", default=list(DATASETS), choices=list(DATASETS))
    p.add_argument("--epochs", type=int, default=PARAMS["epochs"], help="ACBN training epochs (paper: 100)")
    p.add_argument("--folds", type=int, default=SETUPS["k_folds"], help="stratified K-fold (default 10)")
    p.add_argument("--seg-epochs", type=int, default=IMPL["seg_epochs"], help="UF-EANet training epochs")
    p.add_argument("--image-size", type=int, default=SETUPS["base_image_size"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--pseudo-masks", action="store_true", help="use Otsu pseudo masks if a dataset has no GT masks")
    p.add_argument("--no-pretrained", action="store_true", help="do not download ImageNet weights for VGG-19")
    p.add_argument("--quick", action="store_true", help="tiny smoke-test settings (3 epochs, 3 folds)")
    p.add_argument("--out", default=None, help="output folder (default ./results/<analysis>)")
    return p


def finalize(args):
    if args.quick:
        args.epochs, args.folds, args.seg_epochs = 3, 3, 2
    return args


def load_datasets(args):
    info = {}
    for name in args.datasets:
        info[name] = D.discover(os.path.join(args.data_root, DATASETS[name]))
    return info
