"""Attention-guided Deep Broad convolutional neural Network (ADBNet, Section 3.6.1 b, Fig. 4).

Input L_g -> Conv2D -> Conv2D -> BN -> MaxPool+GELU -> 3 x Residual block -> SepConv2D
          -> Deep Broad block -> CBAM -> BN -> Dropout -> Flatten -> Softmax
"""
from tensorflow import keras
from tensorflow.keras import layers, regularizers
import tensorflow as tf

from .config import PARAMS


def _reg():
    return regularizers.l2(PARAMS["weight_decay_l2"])


def _gelu(x):
    return layers.Activation(tf.nn.gelu)(x)


def residual_block(x, filters):
    """Eq. 27/28: x + F(x) with depthwise-separable convs, GELU, then 2x2 max pooling."""
    k = PARAMS["kernel_size"]
    sc = layers.Conv2D(filters, 1, padding="same", kernel_regularizer=_reg())(x)
    y = layers.SeparableConv2D(filters, k, padding="same", depthwise_regularizer=_reg(),
                               pointwise_regularizer=_reg())(x)
    y = layers.BatchNormalization()(y)
    y = _gelu(y)
    y = layers.SeparableConv2D(filters, k, padding="same", depthwise_regularizer=_reg(),
                               pointwise_regularizer=_reg())(y)
    y = layers.BatchNormalization()(y)
    y = layers.Add()([sc, y])
    y = _gelu(y)
    return layers.MaxPooling2D(PARAMS["pool_size"])(y)


def deep_broad_block(q):
    """Eqs. 34-37:  O = GELU(conv(Q)), M = GELU(conv(O)), N = FC(GAP(M)), out = concat(Q, N)."""
    k, c = PARAMS["kernel_size"], PARAMS["broad_feature_maps"]
    o = _gelu(layers.Conv2D(c, k, padding="same", kernel_regularizer=_reg())(q))
    m = _gelu(layers.Conv2D(c, k, padding="same", kernel_regularizer=_reg())(o))
    n = layers.Dense(c, kernel_regularizer=_reg())(layers.GlobalAveragePooling2D()(m))
    n = layers.Reshape((1, 1, c))(n)
    n = layers.Lambda(lambda t: tf.broadcast_to(t[0], tf.concat([tf.shape(t[1])[:3], tf.shape(t[0])[3:]], 0)))([n, q])
    return layers.Concatenate()([q, n])


def cbam(x):
    """Modified CBAM (Eqs. 29-33): channel attention (reduction ratio 16) then 1x1+3x3 spatial attention."""
    ch = x.shape[-1]
    r = max(1, ch // PARAMS["attention_reduction_ratio"])
    w = layers.GlobalAveragePooling2D()(x)
    w = layers.Dense(r, activation="relu", kernel_regularizer=_reg())(w)
    w = layers.Dense(ch, activation="sigmoid", kernel_regularizer=_reg())(w)
    x = layers.Multiply()([x, layers.Reshape((1, 1, ch))(w)])
    avg = layers.Lambda(lambda t: tf.reduce_mean(t, axis=-1, keepdims=True))(x)
    mx = layers.Lambda(lambda t: tf.reduce_max(t, axis=-1, keepdims=True))(x)
    s = layers.Concatenate()([avg, mx])
    s = layers.Conv2D(8, 1, activation="relu", kernel_regularizer=_reg())(s)
    s = layers.Conv2D(1, PARAMS["kernel_size"], padding="same", activation="sigmoid", kernel_regularizer=_reg())(s)
    return layers.Multiply()([x, s])


def adbnet_graph(inp, n_classes):
    """Builds the ADBNet graph on the tensor ``inp`` and returns the softmax output tensor."""
    k = PARAMS["kernel_size"]
    x = layers.Conv2D(16, k, padding="same", activation=PARAMS["activation"], kernel_regularizer=_reg())(inp)
    x = layers.Conv2D(16, k, padding="same", activation=PARAMS["activation"], kernel_regularizer=_reg())(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D(PARAMS["pool_size"])(x)
    x = _gelu(x)
    for f in (32, 64, 64):
        x = residual_block(x, f)
    x = layers.SeparableConv2D(64, k, padding="same", activation=PARAMS["activation"],
                               depthwise_regularizer=_reg(), pointwise_regularizer=_reg())(x)
    x = deep_broad_block(x)
    x = cbam(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(PARAMS["dropout"])(x)
    x = layers.Flatten()(x)
    return layers.Dense(n_classes, activation=PARAMS["output_activation"], kernel_regularizer=_reg())(x)
