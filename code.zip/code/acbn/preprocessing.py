"""Image pre-preparation (Section 3.2): Kernel Wiener Filtering + Histogram Equalization."""
import numpy as np
from .config import IMPL


def estimate_noise_sigma(y):
    """Robust noise std (MAD of a 2x2 difference operator); y in [0, 1]."""
    d = (y[1:, 1:] - y[:-1, 1:] - y[1:, :-1] + y[:-1, :-1]) / 2.0
    return float(1.4826 * np.median(np.abs(d - np.median(d))))


def kernel_wiener_filter(img, window=None, sigma_s=None, range_factor=None):
    """Kernel Wiener Filter (KWF, Eqs. 2-6), pixel-wise form.

    For every pixel ``t`` a c x c patch is extracted (Eqs. 2-3).  The statistics
    of the patch are weighted by a shape-aware kernel ``lambda_t`` (spatial
    Gaussian x edge-preserving range term, i.e. the windowed-variation kernel of
    ref. [19]).  The optimal Wiener filter that minimises the expected squared
    patch error (Eqs. 5-6) is then applied (Eq. 4):

        x_hat = mu_l + max(var_l - sigma_n^2, 0) / var_l * (y - mu_l)
    """
    window = window or IMPL["kwf_window"]
    sigma_s = sigma_s or IMPL["kwf_sigma_spatial"]
    range_factor = range_factor or IMPL["kwf_range_factor"]
    y = img.astype(np.float64) / 255.0
    sigma_n = max(estimate_noise_sigma(y), 1e-4)
    sigma_r = range_factor * sigma_n
    r = window // 2
    p = np.pad(y, r, mode="reflect")
    h, w = y.shape
    sw = np.zeros_like(y); s1 = np.zeros_like(y); s2 = np.zeros_like(y)
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            nb = p[r + dy:r + dy + h, r + dx:r + dx + w]
            k = np.exp(-(dx * dx + dy * dy) / (2 * sigma_s ** 2)) * \
                np.exp(-((nb - y) ** 2) / (2 * sigma_r ** 2))        # shape-aware kernel
            sw += k; s1 += k * nb; s2 += k * nb * nb
    mu = s1 / sw
    var = np.maximum(s2 / sw - mu * mu, 0.0)
    gain = np.maximum(var - sigma_n ** 2, 0.0) / (var + 1e-12)
    out = mu + gain * (y - mu)
    return np.clip(out * 255.0, 0, 255).round().astype(np.uint8)


def histogram_equalization(img, levels=256):
    """Eq. 7: H = round( (CDF(v) - CDF_min) / (M*N - CDF_min) * (K - 1) )."""
    hist = np.bincount(img.ravel(), minlength=levels)
    cdf = np.cumsum(hist)
    nz = cdf[hist > 0]
    cdf_min = nz.min()
    total = img.size
    if total == cdf_min:                       # constant image
        return img.copy()
    lut = np.round((cdf - cdf_min) / (total - cdf_min) * (levels - 1))
    return np.clip(lut, 0, levels - 1).astype(np.uint8)[img]


def prepare(img, kwf=True, he=True):
    """Pre-preparation of one uint8 image (denoise -> enhance)."""
    out = img
    if kwf:
        out = kernel_wiener_filter(out)
    if he:
        out = histogram_equalization(out)
    return out


def prepare_batch(imgs, kwf=True, he=True):
    return np.stack([prepare(i, kwf, he) for i in imgs])


def add_noise(imgs, percentage, rng):
    """Gaussian noise whose std is ``percentage`` % of the image std (robustness test)."""
    imgs = imgs.astype(np.float64)
    out = np.empty_like(imgs)
    for i, im in enumerate(imgs):
        out[i] = im + rng.normal(0.0, percentage / 100.0 * im.std(), im.shape)
    return np.clip(out, 0, 255).round().astype(np.uint8)
