"""Segmentation analysis: IoU / Dice of UF-EANet (unified focal loss) and EANet (BCE loss) vs training data %."""
import json
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from . import data as D
from . import segmentation as S
from .config import IMPL, SETUPS, ROOT
from .isolate import run_isolated
from .pipeline import seg_training_data


def _train_eval(imgs_tr, masks_tr, imgs_te, masks_te, size, epochs, loss, pretrained, seed):
    model = S.train_eanet(imgs_tr, masks_tr, size, epochs, loss, pretrained, 0, seed)
    return S.iou_dice(S.predict_prob(model, imgs_te, size), masks_te)


def run(datasets_info, epochs, seed, allow_pseudo, pretrained, out_root=None):
    out_root = out_root or os.path.join(ROOT, "results", "segmentation_analysis")
    size = IMPL["seg_size"]
    for ds, (records, classes) in datasets_info.items():
        imgs, masks = seg_training_data(records, True, True, allow_pseudo)
        y = D.labels_of(records)
        rows = []
        for pct in SETUPS["train_percentages"]:
            try:
                tr, te = train_test_split(np.arange(len(y)), train_size=pct / 100.0, stratify=y, random_state=seed)
            except ValueError:
                tr, te = train_test_split(np.arange(len(y)), train_size=pct / 100.0, random_state=seed)
            for loss in ("unified", "bce"):
                print(f"[seg-analysis] {ds} train={pct}% loss={loss}")
                cpath = os.path.join(out_root, "_cache", f"{ds}_{pct}_{loss}_e{epochs}_s{seed}_n{len(y)}.json")
                if os.path.exists(cpath):                      # resume support
                    with open(cpath) as fh:
                        iou, dice = json.load(fh)
                else:
                    iou, dice = run_isolated(_train_eval, imgs[tr], masks[tr], imgs[te], masks[te],
                                             size, epochs, loss, pretrained, seed)
                    os.makedirs(os.path.dirname(cpath), exist_ok=True)
                    with open(cpath, "w") as fh:
                        json.dump([iou, dice], fh)
                rows.append({"train_%": pct, "model": "Unified Focal EANet" if loss == "unified" else "EANet (BCE)",
                             "IoU": iou, "Dice": dice})
        d = os.path.join(out_root, ds)
        os.makedirs(d, exist_ok=True)
        df = pd.DataFrame(rows)
        df.to_csv(os.path.join(d, f"{ds}_segmentation.csv"), index=False)
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        for metric in ("IoU", "Dice"):
            fig, ax = plt.subplots(figsize=(6, 4.5))
            for model_name, g in df.groupby("model", sort=False):
                ax.plot(g["train_%"], g[metric], marker="o", linewidth=2, label=model_name)
            ax.set_xlabel("Training data (%)"); ax.set_ylabel(metric); ax.grid(alpha=0.3); ax.legend(); ax.set_title(ds)
            fig.tight_layout(); fig.savefig(os.path.join(d, f"{ds}_{metric.lower()}.png"), dpi=300)
            fig.savefig(os.path.join(d, f"{ds}_{metric.lower()}.svg")); plt.close(fig)
        print(f"[saved] {d}")
