"""Attention-guided Convolutional Belief Network (ACBN, Section 3.6, Fig. 2, Eqs. 37-45).

    B1  = DBN(L_g) * sum_ij(L_g * x1)                  (DBN outcome, Eq. 26 x weight term)
    B2  = ADBNet(L_g) * x2 * B1                        (ADBNet outcome, Eqs. 37-38)
    B_g = 2*B1 - B2                                    (Taylor concept with J = 1, Eq. 44)
    output = softmax(B_g)

x1 is a trainable weight map (same size as L_g), x2 a trainable weight per class.
Everything is trained jointly with Adam (Algorithm 1).
"""
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers

from .config import PARAMS, IMPL
from .adbnet import adbnet_graph
from .dbn import pretrain_dbn


class WeightedSum(layers.Layer):
    """sum_ij (L_g * x1) with trainable x1 (initialised to x1_init_scale * mean filter)."""

    def build(self, input_shape):
        n = int(np.prod(input_shape[1:]))
        self.x1 = self.add_weight(name="x1", shape=tuple(input_shape[1:]),
                                  initializer=keras.initializers.Constant(IMPL["x1_init_scale"] / n), trainable=True)

    def call(self, x):
        return tf.reduce_sum(x * self.x1, axis=list(range(1, len(x.shape))))[:, None]


class ClassWeight(layers.Layer):
    """x2 : one trainable weight per class."""

    def build(self, input_shape):
        self.x2 = self.add_weight(name="x2", shape=(input_shape[-1],),
                                  initializer="ones", trainable=True)

    def call(self, x):
        return x * self.x2


def _dbn_graph(hist_in, n_classes, stack):
    x = hist_in
    for i, h in enumerate(PARAMS["dbn_hidden_neurons"]):
        init = None
        if stack is not None:
            W, b = stack[i]
            init = (keras.initializers.Constant(W), keras.initializers.Constant(b))
        x = layers.Dense(h, activation="sigmoid",
                         kernel_initializer=init[0] if init else "glorot_uniform",
                         bias_initializer=init[1] if init else "zeros",
                         kernel_regularizer=regularizers.l2(PARAMS["weight_decay_l2"]))(x)
    return layers.Dense(n_classes, activation=PARAMS["output_activation"],
                        kernel_regularizer=regularizers.l2(PARAMS["weight_decay_l2"]))(x)


def build_model(map_size, hist_dim, n_classes, variant="acbn", dbn_stack=None):
    """variant: 'acbn' (proposed), 'adbnet' (ADBNet only) or 'dbn' (DBN only)."""
    lmap = keras.Input((map_size, map_size, 1), name="Lg_map")
    hist = keras.Input((hist_dim,), name="Lg_hist")
    if variant == "adbnet":
        return keras.Model([lmap, hist], adbnet_graph(lmap, n_classes))
    v1 = _dbn_graph(hist, n_classes, dbn_stack)
    if variant == "dbn":
        return keras.Model([lmap, hist], v1)
    v2 = adbnet_graph(lmap, n_classes)
    s1 = WeightedSum(name="sum_L_x1")(lmap)
    b1 = layers.Lambda(lambda t: t[0] * t[1])([v1, s1])                    # B1
    b2 = layers.Lambda(lambda t: t[0] * t[1])([ClassWeight(name="x2")(v2), b1])   # B2
    bg = layers.Lambda(lambda t: 2.0 * t[0] - t[1], name="taylor")([b1, b2])      # Eq. 44
    return keras.Model([lmap, hist], layers.Softmax()(bg))


def train_and_predict(train, test, n_classes, variant="acbn", epochs=None, seed=0, verbose=0):
    """train / test = (maps uint8 (N,S,S), hists (N,D), labels (N,)).  Returns predicted labels of test."""
    keras.utils.set_random_seed(seed)
    tr_map, tr_hist, tr_y = train
    te_map, te_hist, _ = test
    size, dim = tr_map.shape[1], tr_hist.shape[1]
    # per-dimension min-max scaling of the descriptor, fitted on the training fold only
    lo, hi = tr_hist.min(0), tr_hist.max(0)
    scale = lambda h: np.clip((h - lo) / np.maximum(hi - lo, 1e-6), 0.0, 1.0).astype(np.float32)
    tr_hist, te_hist = scale(tr_hist), scale(te_hist)
    stack = pretrain_dbn(tr_hist, seed=seed) if variant in ("acbn", "dbn") else None
    model = build_model(size, dim, n_classes, variant, stack)
    model.compile(optimizer=keras.optimizers.Adam(PARAMS["learning_rate"], beta_1=PARAMS["beta_1"],
                                                  beta_2=PARAMS["beta_2"]),
                  loss=PARAMS["loss"], metrics=[])
    cb = [keras.callbacks.ReduceLROnPlateau(monitor="loss", factor=IMPL["rop_factor"],
                                            patience=IMPL["rop_patience"], min_lr=IMPL["rop_min_lr"])]
    y = keras.utils.to_categorical(tr_y, n_classes)
    model.fit([tr_map[..., None].astype(np.float32) / 255.0, tr_hist.astype(np.float32)], y,
              batch_size=PARAMS["batch_size"], epochs=epochs or PARAMS["epochs"],
              callbacks=cb, verbose=verbose, shuffle=True)
    prob = model.predict([te_map[..., None].astype(np.float32) / 255.0, te_hist.astype(np.float32)],
                         batch_size=PARAMS["batch_size"], verbose=0)
    keras.backend.clear_session()
    return prob.argmax(1)
