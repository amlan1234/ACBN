"""Cutout augmentation (Section 3.4, Eq. 19)."""
import numpy as np
from .config import IMPL


def cutout(img, rng, fill=0):
    """Remove one random rectangle:  O(p,q) = fill  if p0<=p<p0+w and q0<=q<q0+v, else O(p,q)."""
    h, w = img.shape[:2]
    ch = int(rng.integers(max(1, int(IMPL["cutout_min_frac"] * h)), max(2, int(IMPL["cutout_max_frac"] * h)) + 1))
    cw = int(rng.integers(max(1, int(IMPL["cutout_min_frac"] * w)), max(2, int(IMPL["cutout_max_frac"] * w)) + 1))
    p0 = int(rng.integers(0, h - ch + 1))
    q0 = int(rng.integers(0, w - cw + 1))
    out = img.copy()
    out[p0:p0 + ch, q0:q0 + cw] = fill
    return out
