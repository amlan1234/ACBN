"""Central configuration.

Everything that comes from the paper (Table 1, Section 3, Section 4) lives in
``PARAMS``.  Values the paper does *not* specify are in ``IMPL`` so that it is
always clear which numbers are paper-given and which are implementation choices.
"""
import os

# --------------------------------------------------------------------------
# Metrics returned by every classification run (order matters)
# --------------------------------------------------------------------------
YL = {"acc": "Accuracy(%)", "tpr": "TPR(%)", "mcc": "MCC",
      "pre": "Precision(%)", "f1s": "F1-score(%)", "spe": "Specificity(%)"}
METRIC_KEYS = list(YL.keys())

# --------------------------------------------------------------------------
# Table 1 of the paper - parameter settings of ACBN
# --------------------------------------------------------------------------
PARAMS = {
    "batch_size": 32,
    "epochs": 100,
    "learning_rate": 1e-3,            # initial learning rate
    "lr_scheduler": "ReduceLROnPlateau",
    "optimizer": "Adam",
    "beta_1": 0.9,
    "beta_2": 0.999,
    "weight_decay_l2": 1e-4,
    "dropout": 0.5,
    "activation": "relu",
    "output_activation": "softmax",
    "loss": "categorical_crossentropy",
    "attention_reduction_ratio": 16,
    "kernel_size": 3,                 # 3 x 3 convolutions
    "pool_size": 2,                   # 2 x 2 max pooling
    "broad_feature_maps": 64,         # Deep Broad block width
    "dbn_hidden_layers": 3,
    "dbn_hidden_neurons": (512, 256, 128),
    "rbm_learning_rate": 0.01,
    "rbm_batch_size": 64,
}

# --------------------------------------------------------------------------
# Implementation choices that the paper leaves open
# --------------------------------------------------------------------------
IMPL = {
    # ReduceLROnPlateau (Table 1 names it but gives no arguments)
    "rop_factor": 0.5, "rop_patience": 5, "rop_min_lr": 1e-6,
    # initial magnitude of the trainable weight map x1 (sum_ij L*x1 starts at ~x1_init_scale * mean(L));
    # a larger start avoids near-identical softmax logits at the Taylor output (Eq. 44)
    "x1_init_scale": 10.0,
    # RBM layer-wise pre-training length (Section 3.6.1 a)
    "rbm_epochs": 10,
    # Kernel Wiener Filter (Eqs. 2-6): window c x c and kernel widths
    "kwf_window": 5, "kwf_sigma_spatial": 1.5, "kwf_range_factor": 3.0,
    # CSC-LBP (Section 3.5): P neighbours, radius R
    "lbp_points": 8, "lbp_radius": 1,
    # Cutout (Eq. 19): size of the removed rectangle as a fraction of the side
    "cutout_min_frac": 0.10, "cutout_max_frac": 0.40, "cutout_copies": 1,
    # Segmentation network
    "seg_size": 128, "seg_epochs": 50, "seg_batch": 8, "seg_lr": 1e-4,
    "seg_dsc_dilations": (1, 3, 5), "seg_channels": 128,
    # Unified focal loss hyper-parameters (Eqs. 12-18; defaults of Yeung et al.)
    "uf_eta": 0.6, "uf_chi": 0.5, "uf_psi": 0.5,
    "seg_threshold": 0.5, "seg_empty_fallback": True,
    # Metric averaging for multi-class data
    "metric_average": "macro",
}

# --------------------------------------------------------------------------
# Experimental setups (Section 4.7 - 4.9 of the paper + the two new analyses)
# --------------------------------------------------------------------------
SETUPS = {
    "image_sizes": [32, 64, 128, 256, 512],          # scalability
    "noise_percentages": [5, 10, 15, 20, 25],        # robustness
    "train_percentages": [50, 60, 70, 80, 90],       # segmentation analysis
    "k_folds": 10,
    "base_image_size": 128,                          # operating size for all other analyses
    "robustness_noise_default": 25,
}

# --------------------------------------------------------------------------
# Datasets : sub-folder under --data-root.  Class = first sub-folder of the dataset.
# --------------------------------------------------------------------------
DATASETS = {"MIAS": "MIAS", "DDSM": "DDSM_DB2"}

# Analysis variants -----------------------------------------------------------
PREPROCESSING_VARIANTS = {
    "ACBN without preprocessing": dict(kwf=False, he=False),
    "ACBN with Kernel Wiener filtering": dict(kwf=True, he=False),
    "ACBN with Histogram Equalization": dict(kwf=False, he=True),
    "ACBN with Kernel Wiener filtering + Histogram Equalization": dict(kwf=True, he=True),
}
ABLATION_VARIANTS = {
    "ACBN without Kernel Wiener filtering": dict(kwf=False),
    "ACBN without Histogram Equalization": dict(he=False),
    "ACBN without EANet": dict(seg=False),
    "ACBN without Cutout augmentation": dict(cutout=False),
    "ACBN without CSC-LBP": dict(csc=False),
    "ADBNet": dict(model="adbnet"),
    "DBN": dict(model="dbn"),
    "Proposed ACBN": dict(),
}

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
