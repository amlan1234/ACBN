"""Deep Belief Network pre-training (Section 3.6.1 a): greedy layer-wise Bernoulli RBMs (CD-1)."""
import numpy as np
from .config import PARAMS, IMPL


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


class RBM:
    def __init__(self, n_vis, n_hid, rng):
        self.W = rng.normal(0.0, 0.01, (n_vis, n_hid))
        self.b_v = np.zeros(n_vis)          # visible bias  (beta in the paper)
        self.b_h = np.zeros(n_hid)          # hidden bias   (alpha in the paper)
        self.rng = rng

    def hidden(self, v):
        return _sigmoid(v @ self.W + self.b_h)

    def fit(self, X, lr, batch, epochs):
        n = len(X)
        for _ in range(epochs):
            order = self.rng.permutation(n)
            for s in range(0, n, batch):
                v0 = X[order[s:s + batch]]
                ph0 = self.hidden(v0)
                h0 = (self.rng.random(ph0.shape) < ph0).astype(np.float64)
                pv1 = _sigmoid(h0 @ self.W.T + self.b_v)
                ph1 = self.hidden(pv1)
                m = len(v0)
                self.W += lr * (v0.T @ ph0 - pv1.T @ ph1) / m
                self.b_v += lr * (v0 - pv1).mean(0)
                self.b_h += lr * (ph0 - ph1).mean(0)
        return self


def pretrain_dbn(X, hidden=None, lr=None, batch=None, epochs=None, seed=0):
    """Returns a list of (W, b_h) used to initialise the DBN dense layers."""
    hidden = hidden or PARAMS["dbn_hidden_neurons"]
    lr = lr or PARAMS["rbm_learning_rate"]
    batch = batch or PARAMS["rbm_batch_size"]
    epochs = epochs if epochs is not None else IMPL["rbm_epochs"]
    rng = np.random.default_rng(seed)
    data = np.clip(X.astype(np.float64), 0.0, 1.0)
    stack = []
    for h in hidden:
        rbm = RBM(data.shape[1], h, rng).fit(data, lr, batch, epochs)
        stack.append((rbm.W.astype(np.float32), rbm.b_h.astype(np.float32)))
        data = rbm.hidden(data)
    return stack
