"""Publication-style plots (png + svg).  Each setting is drawn as mean +/- std over the folds."""
import textwrap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

PALETTE = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3", "#8C8C8C"]


def _save(fig, base):
    fig.tight_layout()
    fig.savefig(base + ".png", dpi=300)
    fig.savefig(base + ".svg")
    plt.close(fig)


def plot_bars(base, labels, values, ylabel, title=None):
    mean = [v.mean() for v in values]
    std = [v.std() for v in values]
    fig, ax = plt.subplots(figsize=(max(6, 1.1 * len(labels) + 2), 4.8))
    x = np.arange(len(labels))
    ax.bar(x, mean, yerr=std, capsize=4, color=[PALETTE[i % len(PALETTE)] for i in range(len(labels))],
           edgecolor="black", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([textwrap.fill(l.replace("ACBN ", ""), 16) for l in labels], fontsize=8)
    ax.set_ylabel(ylabel)
    lo = min(m - s for m, s in zip(mean, std))
    hi = max(m + s for m, s in zip(mean, std))
    pad = max((hi - lo) * 0.15, 1e-3)
    ax.set_ylim(lo - pad, hi + pad)
    ax.grid(axis="y", alpha=0.3)
    if title:
        ax.set_title(title)
    _save(fig, base)


def plot_lines(base, x_values, values, ylabel, xlabel, title=None):
    mean = np.array([v.mean() for v in values])
    std = np.array([v.std() for v in values])
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.errorbar(range(len(x_values)), mean, yerr=std, marker="o", capsize=4, color=PALETTE[0], linewidth=2)
    ax.set_xticks(range(len(x_values)))
    ax.set_xticklabels([str(x) for x in x_values])
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    if title:
        ax.set_title(title)
    _save(fig, base)
